import asyncio
import os
import sys
import webbrowser
from pathlib import Path

# 将项目根目录添加到Python路径
sys.path.append(str(Path(__file__).parent.parent))

from app.agent.manus import Manus
from app.logger import logger


async def run_niuma_calculator():
    """运行牛马指数计算器"""
    agent = Manus()
    try:
        print("=" * 50)
        print("欢迎使用牛马指数计算器")
        print("=" * 50)
        print("\n请输入您的工作信息，我们将为您计算牛马指数。")

        # 收集用户信息
        work_hours = input("\n您的日均工作时长（小时）: ")
        overtime = input("您的加班频率（几乎不加班/偶尔加班/经常加班/几乎天天加班）: ")
        holiday_work = input(
            "您的节假日工作情况（正常休息/偶尔需要工作/经常需要工作/几乎没有假期）: "
        )
        monthly_salary = input("您的月薪（元）: ")
        commute_time = input("您的单程通勤时间（分钟）: ")
        work_env = input("您对工作环境的评分（1-10分）: ")
        relationship = input("您对工作人际关系的评分（1-10分）: ")

        # 构建完整的提示词
        prompt = f"""
        请根据以下信息计算我的牛马指数：
        - 日均工作时长：{work_hours}小时
        - 加班频率：{overtime}
        - 节假日工作情况：{holiday_work}
        - 月薪：{monthly_salary}元
        - 单程通勤时间：{commute_time}分钟
        - 工作环境评分：{work_env}分
        - 工作人际关系评分：{relationship}分

        请详细分析我的工作情况，并用幽默风趣的方式提供建议，生成一个美观的网页展示结果。
        """

        print("\n正在分析您的工作情况，请稍等...")
        await agent.run(prompt)
        print("\n分析完成！网页报告已生成。")

    except KeyboardInterrupt:
        print("\n计算已取消。")
    except Exception as e:
        print(f"\n出现错误: {e}")
    finally:
        # 确保资源被清理
        await agent.cleanup()


if __name__ == "__main__":
    asyncio.run(run_niuma_calculator())
