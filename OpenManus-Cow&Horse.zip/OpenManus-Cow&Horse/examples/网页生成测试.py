import os
import tempfile
import webbrowser
from pathlib import Path

# 获取项目根目录路径
ROOT_DIR = Path(__file__).parent.parent
ASSETS_DIR = ROOT_DIR / "assets"
BACKGROUND_IMG = ASSETS_DIR / "website_background.png"


def generate_test_html():
    """生成测试HTML网页并在浏览器中打开"""

    # 确保背景图片存在
    if not BACKGROUND_IMG.exists():
        print(f"错误：背景图片不存在于 {BACKGROUND_IMG}")
        return False

    # 绝对路径用于HTML文件
    bg_img_path = BACKGROUND_IMG.absolute().as_uri()

    # 生成简单的HTML内容
    html_content = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>牛马指数分析报告 - 测试</title>
    <style>
        body {{
            background-image: url('{bg_img_path}');
            background-size: cover;
            font-family: 'Arial', sans-serif;
            color: #333;
            padding: 20px;
        }}
        .container {{
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 15px;
            padding: 30px;
            max-width: 800px;
            margin: 50px auto;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
        }}
        h1 {{
            color: #e74c3c;
            text-align: center;
        }}
        .score {{
            font-size: 36px;
            text-align: center;
            color: #e74c3c;
            margin: 20px 0;
        }}
        .analysis {{
            line-height: 1.6;
        }}
        .comparison {{
            background-color: #f9f9f9;
            padding: 15px;
            border-radius: 10px;
            margin: 20px 0;
        }}
        .advice {{
            background-color: #e8f4f8;
            padding: 15px;
            border-radius: 10px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🐮🐴 牛马指数分析报告 - 测试页面 🐮🐴</h1>
        <div class="score">示例牛马指数：7.8</div>

        <div class="analysis">
            <p>这是一个测试页面，验证背景图片是否正确加载。如果您能看到这个页面上有背景图片，说明测试成功！</p>
            <p>背景图片路径: {bg_img_path}</p>
        </div>

        <div class="comparison">
            <h3>比较示例</h3>
            <p>这里应该显示与其他行业的比较信息。</p>
        </div>

        <div class="advice">
            <h3>建议示例</h3>
            <p>这里应该显示给用户的建议。</p>
        </div>
    </div>
</body>
</html>"""

    # 创建临时HTML文件
    with tempfile.NamedTemporaryFile(
        "w", delete=False, suffix=".html", encoding="utf-8"
    ) as f:
        f.write(html_content)
        temp_html_path = f.name

    print(f"生成了测试HTML页面: {temp_html_path}")

    # 在浏览器中打开
    webbrowser.open(f"file://{temp_html_path}")

    return True


if __name__ == "__main__":
    print("正在生成测试网页...")
    if generate_test_html():
        print("测试网页已在浏览器中打开，请检查背景图片是否正确显示。")
    else:
        print("测试失败，无法生成网页。")
